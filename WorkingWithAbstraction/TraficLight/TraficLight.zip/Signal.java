package WorkingWithAbstraction.TraficLight;

public enum Signal {
    RED,
    GREEN,
    YELLOW
}
